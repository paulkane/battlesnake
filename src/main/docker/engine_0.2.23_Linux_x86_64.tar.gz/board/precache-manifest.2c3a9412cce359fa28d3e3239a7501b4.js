self.__precacheManifest = [
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "199b37b400c41bf2d98c",
    "url": "/static/js/main.199b37b4.chunk.js"
  },
  {
    "revision": "f4914188c4941f7ec694",
    "url": "/static/js/1.f4914188.chunk.js"
  },
  {
    "revision": "0feec85f1d6fe3179e36a108eff3487a",
    "url": "/index.html"
  }
];